
Metabolites-Classification
****************************************************************************************************************************************************

 1. Introduction

Metabolites-Classification is meant to serve as a machine learning-based nanopore analysis platform using MATLAB 
to automate classification of events respectively resulted from two binding modes of DHMA (catecholamine acid metabolite).


 It contains three steps as follows:                                
 a. Train Classifier using training dataset
 b. Make predictions with the returned 'trainedClassifier' on predicting dataset
 c. Plot learning curve to evaluate the classifier

 2. Operating procedures: 

 -Unzip the MetabolitesClassifier.rar to local folder, and open the MetabolitesClassifier.m in MATLAB

 -Enter the file name in line 5, line 36 (step 1) and line 71 (step 3) to index the training dataset. // example: training dataset_1+2_feat.xlsx, where 1 represents VMA and 2 represents DOPAC
 -Enter the file name in line 62 (step 2) to index the predicting dataset. // example: predicting dataset_3_unlabelledfeat.xlsx, where 3 represents DHMA

 -Enter a label corresponding to the predicting dataset at line 63 (step2) for the prediction result. // example: DHMA_prediction

 -Specify names for the .xlsx files of the predict results at line 65 (step2). // example: 3_results_predict.xlsx
 -Specify a name for the .xlsx file of the learning curve at line 138 (step3). // example: learning_curve_SVMclassifier.xlsx

 -Run MetabolitesClassifier.m
 -Record the value of the variable ‘validationAccuracy’ in the workspace, which is the validation accuracy of this classifier.
 -Select File > Save As in the Figure window to save the confusion matrix. Specify the saved file location, name, and type.
