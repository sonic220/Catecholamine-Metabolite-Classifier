% STEP 1: Train Classifier using training dataset

% Extract predictors and response
% This code processes the data into the right shape for training the model.
inputTable = readtable('training dataset_1+2_feat.xlsx');% Enter the file name to index the training dataset.//training dataset_1+2_feat.xlsx, where 1 represents VMA and 2 represents DOPAC
predictorNames = {'Mean', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
predictors = inputTable(:, predictorNames);
response = inputTable.label;
isCategoricalPredictor = [false, false, false, false, false, false, false];

% Train a classifier
% This code specifies all the classifier options and trains the classifier.
classificationSVM = fitcsvm(...
    predictors, ...
    response, ...
    'KernelFunction', 'linear', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [1; 2]);% 1 represents VMA and 2 represents DOPAC

% Create the result struct with predict function
predictorExtractionFcn = @(t) t(:, predictorNames);
svmPredictFcn = @(x) predict(classificationSVM, x);
trainedClassifier.predictFcn = @(x) svmPredictFcn(predictorExtractionFcn(x));

% Add additional fields to the result struct
trainedClassifier.RequiredVariables = {'FWHM', 'Mean', 'Time', 'kurt', 'peak', 'skew', 'std'};
trainedClassifier.ClassificationSVM = classificationSVM;
trainedClassifier.About = 'This struct is a trained model exported from Classification Learner R2021a.';
trainedClassifier.HowToPredict = sprintf('To make predictions on a new table, T, use: \n  yfit = c.predictFcn(T) \nreplacing ''c'' with the name of the variable that is this struct, e.g. ''trainedModel''. \n \nThe table, T, must contain the variables returned by: \n  c.RequiredVariables \nVariable formats (e.g. matrix/vector, datatype) must match the original training data. \nAdditional variables are ignored. \n \nFor more information, see <a href="matlab:helpview(fullfile(docroot, ''stats'', ''stats.map''), ''appclassification_exportmodeltoworkspace'')">How to predict using an exported model</a>.');

% Extract predictors and response
% This code processes the data into the right shape for training the model.
inputTable = readtable('training dataset_1+2_feat.xlsx');% Enter the file name to index the training dataset.//training dataset_1+2_feat.xlsx, where 1 represents VMA and 2 represents DOPAC
predictorNames = {'Mean', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
predictors = inputTable(:, predictorNames);
response = inputTable.label;
isCategoricalPredictor = [false, false, false, false, false, false, false];

% Perform cross-validation
partitionedModel = crossval(trainedClassifier.ClassificationSVM, 'KFold', 10);

% Compute validation predictions
[validationPredictions, validationScores] = kfoldPredict(partitionedModel);

% Compute resubstitution accuracy
resubstitutionAccuracy = 1 - resubLoss(trainedClassifier.ClassificationSVM);
 
% Compute validation accuracy
validationAccuracy = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');

% Export confusion matrix
cm = confusionchart(response,validationPredictions, ...
    'Title','Confusion Matrix of SVM', ...
    'RowSummary','row-normalized');


% STEP 2: Make prediction with the returned 'trainedClassifier' on testing dataset

DHMA_table = readtable('predicting dataset_3_unlabelledfeat.xlsx');%Import testing dataset.//predicting dataset_3_unlabelledfeat.xlsx, where 3 represents DHMA
prediction_results = ("DHMA_prediction");
label_predict = table(trainedClassifier.predictFcn(DHMA_table),'VariableNames',prediction_results);%Make prediction and output the labels
filename1 = '3_results_predict.xlsx';
writetable(label_predict,filename1,'Sheet',1,'Range','A1');%Export the predicted labels to an xlsx file


% STEP 3 Plot learning curve to evaluate the classifier

trainingData = readtable('training dataset_1+2_feat.xlsx');% Enter the file name to index the training dataset.//training dataset_1+2_feat.xlsx, where 1 represents VMA and 2 represents DOPAC
param = trainingData(:,8);
a = height(param);%The total number of samples in the training dataset,733
x = [];
y_resub = [];
y_validation = [];
for i = 30:3:733;
    x = [x i]; 
    Sample = trainingData(randi(a,1,i),:);%Randomly select i rows of inputTable as the new training dataset to retrain the classifier

% Extract predictors and response
% This code processes the data into the right shape for training the model.
inputTable = Sample;% Enter the file name to index the training dataset
predictorNames = {'Mean', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
predictors = inputTable(:, predictorNames);
response = inputTable.label;
isCategoricalPredictor = [false, false, false, false, false, false, false];

% Train a classifier
% This code specifies all the classifier options and trains the classifier.
classificationSVM = fitcsvm(...
    predictors, ...
    response, ...
    'KernelFunction', 'linear', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [1; 2]);% 1 represents VMA and 2 represents DOPAC

% Create the result struct with predict function
predictorExtractionFcn = @(t) t(:, predictorNames);
svmPredictFcn = @(x) predict(classificationSVM, x);
trainedClassifier.predictFcn = @(x) svmPredictFcn(predictorExtractionFcn(x));

% Add additional fields to the result struct
trainedClassifier.RequiredVariables = {'FWHM', 'Mean', 'Time', 'kurt', 'peak', 'skew', 'std'};
trainedClassifier.ClassificationSVM = classificationSVM;
trainedClassifier.About = 'This struct is a trained model exported from Classification Learner R2021a.';
trainedClassifier.HowToPredict = sprintf('To make predictions on a new table, T, use: \n  yfit = c.predictFcn(T) \nreplacing ''c'' with the name of the variable that is this struct, e.g. ''trainedModel''. \n \nThe table, T, must contain the variables returned by: \n  c.RequiredVariables \nVariable formats (e.g. matrix/vector, datatype) must match the original training data. \nAdditional variables are ignored. \n \nFor more information, see <a href="matlab:helpview(fullfile(docroot, ''stats'', ''stats.map''), ''appclassification_exportmodeltoworkspace'')">How to predict using an exported model</a>.');

% Extract predictors and response
% This code processes the data into the right shape for training the model.
inputTable = Sample;% Enter the file name to index the training dataset
predictorNames = {'Mean', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
predictors = inputTable(:, predictorNames);
response = inputTable.label;
isCategoricalPredictor = [false, false, false, false, false, false, false];

% Perform cross-validation
partitionedModel = crossval(trainedClassifier.ClassificationSVM, 'KFold', 10);

% Compute validation predictions
[validationPredictions, validationScores] = kfoldPredict(partitionedModel);

% Compute resubstitution accuracy
resubstitutionAccuracy = 1 - resubLoss(trainedClassifier.ClassificationSVM);
 
% Compute validation accuracy
validationAccuracy = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');
y_resub = [y_resub resubstitutionAccuracy];
y_validation = [y_validation validationAccuracy];
end
result_resub = [x(:) y_resub(:)];
result_validation = [x(:) y_validation(:)];
tab1=table(result_resub(:,:));
tab2=table(result_validation(:,:));
filename2 = 'learning_curve_SVMclassifier.xlsx';
writetable(tab2,filename2,'Sheet',1,'Range','D1');%Output results to an xlsx file
writetable(tab1,filename2,'Sheet',1,'Range','A1');%Output results to an xlsx file